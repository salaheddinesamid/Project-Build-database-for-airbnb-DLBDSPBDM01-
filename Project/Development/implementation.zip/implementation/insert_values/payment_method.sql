INSERT INTO PaymentMethod (PaymentMethodID, MethodName)
VALUES
    (1, 'Credit Card'),
    (2, 'Debit Card'),
    (3, 'PayPal'),
    (4, 'Bank Transfer');
