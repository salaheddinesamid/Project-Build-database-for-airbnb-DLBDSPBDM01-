CREATE TABLE SocialMediaPlatform (
    platform_id INTEGER NOT NULL PRIMARY KEY,
    platform_name VARCHAR(100),
    website_url VARCHAR(200)
);


--DONE--