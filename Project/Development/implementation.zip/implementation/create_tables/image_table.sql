CREATE TABLE Image(
    imageID INTEGER NOT NULL PRIMARY KEY,
    image_url VARCHAR(200),
    mediaType VARCHAR(100)
)