CREATE TABLE Policy (
    policyID INTEGER NOT NULL PRIMARY KEY,
    policy_description VARCHAR(250)
);

--POLICY--