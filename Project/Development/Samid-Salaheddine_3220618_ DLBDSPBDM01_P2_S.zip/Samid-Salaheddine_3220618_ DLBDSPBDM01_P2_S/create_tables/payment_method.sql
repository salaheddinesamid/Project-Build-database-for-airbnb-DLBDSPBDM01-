CREATE TABLE PaymentMethod(
    PaymentMethodID INTEGER NOT NULL PRIMARY KEY,
    MethodName VARCHAR(200)
);

--DONE--