CREATE TABLE Country(
    country_id INTEGER NOT NULL PRIMARY KEY,
    COUNTRY_name character varying(100) NOT NULL,
    country_code character varying(3) NOT NULL
);