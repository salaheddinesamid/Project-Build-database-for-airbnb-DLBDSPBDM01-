CREATE TABLE User(
    UserID INTEGER NOT NULL PRIMARY KEY,
    Name VARCHAR(200),
    Email VARCHAR(100),
    Phone VARCHAR(100),
    ProfilePicture VARCHAR(250),
    VerifiedStatus BOOLEAN
    );

    --DONE--