CREATE TABLE Amenity(
    amenityID INTEGER NOT NULL PRIMARY KEY,
    amenityName VARCHAR(200)
)

--DONE--